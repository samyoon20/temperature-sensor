char ds_init(void);
void ds_convert(void);
char ds_temp(unsigned char *);
